
  # 个人博客网站设计

  This is a code bundle for 个人博客网站设计. The original project is available at https://www.figma.com/design/VLnGa0G6XVEoGwqOk4FZcn/%E4%B8%AA%E4%BA%BA%E5%8D%9A%E5%AE%A2%E7%BD%91%E7%AB%99%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  