import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { BlogCard } from './components/BlogCard';
import { Sidebar } from './components/Sidebar';

export default function App() {
  const blogPosts = [
    {
      title: 'React 18 新特性深度解析',
      excerpt: '深入探讨 React 18 中的并发渲染、自动批处理、Suspense 等核心特性，以及它们如何提升应用性能和用户体验。',
      date: '2026-05-15',
      readTime: '8 分钟',
      tags: ['React', 'JavaScript', '前端'],
      image: 'https://images.unsplash.com/photo-1542831371-29b0f74f9713?w=800&q=80',
    },
    {
      title: 'TypeScript 高级类型系统实战',
      excerpt: '从泛型、联合类型到条件类型，全面掌握 TypeScript 的类型系统，让你的代码更加健壮和可维护。',
      date: '2026-05-12',
      readTime: '12 分钟',
      tags: ['TypeScript', '类型系统'],
      image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&q=80',
    },
    {
      title: 'Node.js 性能优化最佳实践',
      excerpt: '探索 Node.js 应用的性能瓶颈和优化策略，包括事件循环、内存管理、集群模式等关键技术点。',
      date: '2026-05-10',
      readTime: '10 分钟',
      tags: ['Node.js', '后端', '性能'],
      image: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=800&q=80',
    },
    {
      title: '算法与数据结构：动态规划入门',
      excerpt: '通过经典问题学习动态规划的思想和解题技巧，掌握状态定义、状态转移方程等核心概念。',
      date: '2026-05-08',
      readTime: '15 分钟',
      tags: ['算法', 'Python', '数据结构'],
      image: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?w=800&q=80',
    },
    {
      title: 'Docker 容器化实战指南',
      excerpt: '从基础概念到实际应用，学习如何使用 Docker 构建、部署和管理容器化应用，提升开发效率。',
      date: '2026-05-05',
      readTime: '11 分钟',
      tags: ['Docker', 'DevOps', '容器'],
      image: 'https://images.unsplash.com/photo-1607799279861-4dd421887fb3?w=800&q=80',
    },
    {
      title: '微服务架构设计模式',
      excerpt: '深入了解微服务架构的核心设计模式，包括 API 网关、服务发现、断路器等，构建可扩展的分布式系统。',
      date: '2026-05-02',
      readTime: '14 分钟',
      tags: ['微服务', '系统设计', '架构'],
      image: 'https://images.unsplash.com/photo-1542831371-29b0f74f9713?w=800&q=80',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950">
      <Header />

      <main>
        <Hero />

        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <div className="mb-8">
                <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
                  最新文章
                </h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  探索计算机科学的精彩世界
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {blogPosts.map((post, index) => (
                  <BlogCard key={index} {...post} index={index} />
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-gray-200/50 dark:border-gray-800/50">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="text-center text-sm text-gray-500 dark:text-gray-400">
            <p>© 2026 计算机博客. 用心分享技术知识</p>
            <p className="mt-2">Built with React + Tailwind CSS + Motion</p>
          </div>
        </div>
      </footer>
    </div>
  );
}